#!/bin/sh
# valgrind_run.sh - memory, fd-leak and data-race checks.
#   memcheck : the unit tests + the real ./mycp with several option combinations
#   helgrind / drd : the multi-threaded copy (-r -j 4)
# Exit status is non-zero if valgrind reports any error.
cd "$(dirname "$0")/.." || exit 1
BIN=./mycp
OUT=reports/valgrind.txt
VG="valgrind -q --error-exitcode=99 --leak-check=full --show-leak-kinds=all --errors-for-leak-kinds=all --track-origins=yes"
T=$(mktemp -d /tmp/mycp_vg.XXXXXX)
trap 'rm -rf "$T"' EXIT
mkdir -p reports; : > "$OUT"; fail=0

run() {  # run <label> <command...>
    label=$1; shift
    "$@" >"$T/out" 2>"$T/err"; rc=$?
    if [ $rc -eq 99 ]; then echo "FAIL  $label" | tee -a "$OUT"; cat "$T/err" >> "$OUT"; fail=1
    else echo "ok    $label (exit $rc)" | tee -a "$OUT"; fi
}

head -c 300000 /dev/urandom > "$T/big"; head -c 100000 "$T/big" > "$T/partial"
mkdir -p "$T/tree/a/b" "$T/tree/empty"
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do head -c $((i * 1000)) /dev/urandom > "$T/tree/f$i"; done
head -c 7000 /dev/urandom > "$T/tree/a/b/y"; ln -s f1 "$T/tree/link"

run "unit tests (memcheck)"        $VG build/test/unit_tests
run "plain copy"                   $VG --track-fds=yes $BIN "$T/big" "$T/o1"
run "-b 1 -i -p -m -v"             $VG --track-fds=yes $BIN -b 1M -i -p -m -v "$T/big" "$T/o2"
run "resume -c -v"                 $VG --track-fds=yes $BIN -c -v "$T/big" "$T/partial"
run "log -l"                       $VG --track-fds=yes $BIN -l "$T/log" "$T/big" "$T/o3"
run "benchmark -B"                 $VG --track-fds=yes $BIN -B "$T/big" "$T/o4"
run "recursive -r -m"              $VG --track-fds=yes $BIN -r -m "$T/tree" "$T/r1"
run "destination inside source"    $VG --track-fds=yes $BIN -r "$T/tree" "$T/tree/out"
run "error: missing source"        $VG $BIN "$T/nope" "$T/o5"
run "error: bad -j"                $VG $BIN -j 0 "$T/big" "$T/o6"
run "helgrind  -r -j 4 -v"         valgrind -q --tool=helgrind --error-exitcode=99 $BIN -r -j 4 -v "$T/tree" "$T/h1"
run "helgrind  -r -j 8 -l"         valgrind -q --tool=helgrind --error-exitcode=99 $BIN -r -j 8 -l "$T/hlog" "$T/tree" "$T/h2"
run "drd       -r -j 4"            valgrind -q --tool=drd --error-exitcode=99 $BIN -r -j 4 "$T/tree" "$T/d1"

echo; if [ $fail -eq 0 ]; then echo "valgrind: ALL CLEAN" | tee -a "$OUT"; else echo "valgrind: ERRORS FOUND (see $OUT)" | tee -a "$OUT"; fi
exit $fail
