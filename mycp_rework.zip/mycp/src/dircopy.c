/* dircopy.c - recursive copy (-r) with worker threads (-j).
 * Phase 1 (one thread):  scan the tree, create the directories, and put every
 *                        file on a linked-list work stack.
 * Phase 2 (N threads):   each worker pops a file from the stack (mutex) and copies it. */
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "mycp.h"

#define DIR_MODE  (S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH)
#define PERM_MASK (S_ISUID | S_ISGID | S_ISVTX | S_IRWXU | S_IRWXG | S_IRWXO)

typedef struct node {           /* list element: a file to copy, or a directory */
    struct node *next;
    char        *src;
    char        *dst;
    mode_t       mode;          /* directories: source permissions (for -m) */
} node_t;

typedef struct {
    const options_t   *opt;
    node_t            *files;       /* work stack: files still to copy                */
    node_t            *dirs_done;   /* scanned directories, chmod'ed at the end (-m)  */
    int                have_skip;   /* identity of the destination root: if it lies   */
    dev_t              skip_dev;    /* inside the source it must not be copied again  */
    ino_t              skip_ino;
    pthread_mutex_t    lock;        /* protects 'files' and the counters below        */
    unsigned long      files_ok;
    unsigned long      files_failed;
    unsigned long long bytes;
} ctx_t;

/* ---------- linked-list helpers ---------- */

static char *dup_str(const char *s)
{
    const size_t n = strlen(s) + 1U;
    char *p = malloc(n);

    if (p != NULL) {
        (void)memcpy(p, s, n);
    }
    return p;
}

static void free_node(node_t *n)
{
    free(n->src);
    free(n->dst);
    free(n);
}

/* put a new node on the front of a list; 0 / -1 (out of memory) */
static int push(node_t **head, const char *src, const char *dst)
{
    node_t *n = malloc(sizeof(*n));

    if (n != NULL) {
        n->src = dup_str(src);
        n->dst = dup_str(dst);
        n->mode = 0;
        n->next = *head;
        if ((n->src == NULL) || (n->dst == NULL)) {
            free_node(n);
            n = NULL;
        } else {
            *head = n;
        }
    }
    if (n == NULL) {
        log_msg(LOG_ERROR, "out of memory");
        return -1;
    }
    return 0;
}

static node_t *pop_job(ctx_t *c)
{
    node_t *n;

    (void)pthread_mutex_lock(&c->lock);
    n = c->files;
    if (n != NULL) {
        c->files = n->next;
    }
    (void)pthread_mutex_unlock(&c->lock);
    return n;
}

/* ---------- phase 1: scan ---------- */

/* one directory entry: sub-directory -> 'todo' list, regular file -> work stack */
static int scan_entry(ctx_t *c, const node_t *dir, const char *name, node_t **todo)
{
    char sp[PATH_MAX];
    char dp[PATH_MAX];
    struct stat st;

    if ((join_path(sp, sizeof(sp), dir->src, name) < 0) || (join_path(dp, sizeof(dp), dir->dst, name) < 0)) {
        log_msg(LOG_ERROR, "path too long under '%s'", dir->src);
        return -1;
    }
    if (lstat(sp, &st) < 0) {
        log_msg(LOG_ERROR, "cannot stat '%s': %s", sp, strerror(errno));
        return -1;
    }
    if ((st.st_dev == c->skip_dev) && (st.st_ino == c->skip_ino)) {
        return 0;                                   /* the destination itself: skip */
    }
    if (S_ISDIR(st.st_mode)) {
        return push(todo, sp, dp);
    }
    if (S_ISREG(st.st_mode)) {
        return push(&c->files, sp, dp);
    }
    log_msg(LOG_INFO, "skipping '%s' (not a regular file or directory)", sp);
    return 0;
}

/* create the destination directory, then look at every entry of the source directory */
static int scan_dir(ctx_t *c, node_t *dir, node_t **todo)
{
    struct stat sst;
    struct stat dst_st;
    const struct dirent *e;
    DIR *d;
    int rc = 0;

    if (stat(dir->src, &sst) < 0) {
        log_msg(LOG_ERROR, "cannot stat '%s': %s", dir->src, strerror(errno));
        return -1;
    }
    if ((mkdir(dir->dst, DIR_MODE) < 0) && (errno != EEXIST)) {
        log_msg(LOG_ERROR, "cannot create directory '%s': %s", dir->dst, strerror(errno));
        return -1;
    }
    if ((stat(dir->dst, &dst_st) < 0) || !S_ISDIR(dst_st.st_mode)) {
        log_msg(LOG_ERROR, "'%s' exists and is not a directory", dir->dst);
        return -1;
    }
    d = opendir(dir->src);
    if (d == NULL) {
        log_msg(LOG_ERROR, "cannot open directory '%s': %s", dir->src, strerror(errno));
        return -1;
    }
    if (c->have_skip == 0) {
        c->have_skip = 1;
        c->skip_dev = dst_st.st_dev;
        c->skip_ino = dst_st.st_ino;
    }
    dir->mode = sst.st_mode & PERM_MASK;
    e = readdir(d);
    while (e != NULL) {
        if ((strcmp(e->d_name, ".") != 0) && (strcmp(e->d_name, "..") != 0) &&
            (scan_entry(c, dir, e->d_name, todo) < 0)) {
            rc = -1;
        }
        e = readdir(d);
    }
    (void)closedir(d);
    return rc;
}

/* breadth-first walk with an explicit list instead of recursion */
static int walk(ctx_t *c, const char *src, const char *dst)
{
    node_t *todo = NULL;
    node_t *dir;
    int rc = push(&todo, src, dst);
    int scan_rc;

    while (todo != NULL) {
        dir = todo;
        todo = dir->next;
        scan_rc = scan_dir(c, dir, &todo);
        if (scan_rc < 0) {
            rc = -1;
        }
        if ((scan_rc == 0) && (c->opt->preserve != 0)) {
            dir->next = c->dirs_done;               /* keep it: chmod at the end */
            c->dirs_done = dir;
        } else {
            free_node(dir);
        }
    }
    return rc;
}

/* ---------- phase 2: copy ---------- */

static void *worker(void *arg)
{
    ctx_t *c = arg;
    node_t *job = pop_job(c);

    while (job != NULL) {
        stats_t st = { 0ULL, 0.0, 0UL, 0UL };
        const int rc = copy_file(job->src, job->dst, c->opt, &st);

        if (rc == 0) {
            say("Copied: %s -> %s (%llu bytes)\n", job->src, job->dst, st.bytes);
        }
        (void)pthread_mutex_lock(&c->lock);
        if (rc == 0) {
            c->files_ok++;
            c->bytes += st.bytes;
        } else {
            c->files_failed++;
        }
        (void)pthread_mutex_unlock(&c->lock);
        free_node(job);
        job = pop_job(c);
    }
    return NULL;
}

int copy_directory(const char *src, const char *dst, const options_t *opt, stats_t *stats)
{
    ctx_t c;
    pthread_t tid[MAX_THREADS];
    const double t0 = now_seconds();
    const int want = (opt->threads > MAX_THREADS) ? MAX_THREADS : opt->threads;
    node_t *d;
    node_t *next;
    int started = 0;
    int more = (want > 1) ? 1 : 0;
    int i;
    int walk_rc;

    (void)memset(&c, 0, sizeof(c));
    c.opt = opt;
    (void)pthread_mutex_init(&c.lock, NULL);
    walk_rc = walk(&c, src, dst);

    /* start up to 'want' threads; if none can be started the main thread does the work */
    while ((more != 0) && (started < want)) {
        more = (pthread_create(&tid[started], NULL, worker, &c) == 0) ? 1 : 0;
        started += more;
    }
    if (started == 0) {
        (void)worker(&c);
    }
    for (i = 0; i < started; i++) {
        (void)pthread_join(tid[i], NULL);
    }

    /* -m : directory permissions last (children before parents) */
    for (d = c.dirs_done; d != NULL; d = next) {
        next = d->next;
        if (chmod(d->dst, d->mode) < 0) {
            log_msg(LOG_ERROR, "cannot set permissions on '%s': %s", d->dst, strerror(errno));
        }
        free_node(d);
    }
    stats->bytes = c.bytes;
    stats->seconds = now_seconds() - t0;
    stats->files_ok = c.files_ok;
    stats->files_failed = c.files_failed;
    (void)pthread_mutex_destroy(&c.lock);
    return ((walk_rc < 0) || (c.files_failed > 0UL)) ? -1 : 0;
}
