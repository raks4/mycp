/* wrap.h - fault injection for the unit tests.
 * The test binary is linked with -Wl,--wrap=<function>, so every call of these libc
 * functions made by mycp's code goes through wrap.c.  A test can make the next call
 * (or the Nth next call) fail once.  Production code is never built with this. */
#ifndef WRAP_H
#define WRAP_H

#ifdef __cplusplus
extern "C" {
#endif

enum { W_MALLOC, W_READ, W_WRITE, W_CLOSE, W_OPENDIR, W_LSTAT, W_CHMOD, W_FCHMOD, W_PTHREAD_CREATE, W_COUNT };

/* the (skip+1)-th next call of 'which' fails once with errno = err */
void wrap_fail(int which, int skip, int err);
void wrap_reset(void);

#ifdef __cplusplus
}
#endif
#endif
