/* wrap.c - the --wrap implementations behind wrap.h */
#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#include "wrap.h"

static int g_skip[W_COUNT] = { -1, -1, -1, -1, -1, -1, -1, -1, -1 };   /* -1 = never fail */
static int g_err[W_COUNT];

void wrap_fail(int which, int skip, int err)
{
    g_err[which] = err;
    __atomic_store_n(&g_skip[which], skip, __ATOMIC_SEQ_CST);
}

void wrap_reset(void)
{
    int i;
    for (i = 0; i < W_COUNT; i++) {
        __atomic_store_n(&g_skip[i], -1, __ATOMIC_SEQ_CST);
    }
}

/* 1 = this call must fail (thread-safe: workers call wrapped functions too) */
static int hit(int which)
{
    if (__atomic_load_n(&g_skip[which], __ATOMIC_SEQ_CST) < 0) {
        return 0;
    }
    if (__atomic_fetch_sub(&g_skip[which], 1, __ATOMIC_SEQ_CST) > 0) {
        return 0;
    }
    errno = g_err[which];
    return 1;
}

void *__real_malloc(size_t n);
ssize_t __real_read(int fd, void *b, size_t n);
ssize_t __real_write(int fd, const void *b, size_t n);
int __real_close(int fd);
DIR *__real_opendir(const char *p);
int __real_lstat(const char *p, struct stat *st);
int __real_chmod(const char *p, mode_t m);
int __real_fchmod(int fd, mode_t m);
int __real_pthread_create(pthread_t *t, const pthread_attr_t *a, void *(*f)(void *), void *arg);

void *__wrap_malloc(size_t n)                          { return hit(W_MALLOC) ? NULL : __real_malloc(n); }
ssize_t __wrap_read(int fd, void *b, size_t n)         { return hit(W_READ) ? -1 : __real_read(fd, b, n); }
ssize_t __wrap_write(int fd, const void *b, size_t n)  { return hit(W_WRITE) ? -1 : __real_write(fd, b, n); }
DIR *__wrap_opendir(const char *p)                     { return hit(W_OPENDIR) ? NULL : __real_opendir(p); }
int __wrap_lstat(const char *p, struct stat *st)       { return hit(W_LSTAT) ? -1 : __real_lstat(p, st); }
int __wrap_chmod(const char *p, mode_t m)              { return hit(W_CHMOD) ? -1 : __real_chmod(p, m); }
int __wrap_fchmod(int fd, mode_t m)                    { return hit(W_FCHMOD) ? -1 : __real_fchmod(fd, m); }

int __wrap_close(int fd)                                /* really closes, then reports the failure */
{
    const int r = __real_close(fd);
    return hit(W_CLOSE) ? -1 : r;
}

int __wrap_pthread_create(pthread_t *t, const pthread_attr_t *a, void *(*f)(void *), void *arg)
{
    return hit(W_PTHREAD_CREATE) ? EAGAIN : __real_pthread_create(t, a, f, arg);
}
