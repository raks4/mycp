# mycp - File Copy Utility using Low-Level I/O

A Linux command-line file copy utility written in C using system calls
(open, read, write, close, lseek, stat, chmod, opendir) instead of the
standard library file functions.

## Build
    make          # builds ./mycp
    make clean

## Usage
    ./mycp [options] <source> <destination>

| Option  | Feature                                              |
|---------|------------------------------------------------------|
| (none)  | Level 1: basic file copy                             |
| -b SIZE | Level 2: configurable buffer size (4096, 64K, 1M)    |
| -i      | Level 3: file information display                    |
| -p      | Level 4: progress bar                                |
| -m      | Level 5: preserve permissions                        |
| -r      | Recursive directory copy                             |
| -j N    | Parallel copy with N pthreads (use with -r)          |
| -B      | Copy performance benchmark (different buffer sizes)  |
| -v      | Copy verification (byte-by-byte compare)             |
| -c      | Resume interrupted copy                              |
| -l FILE | Logging system (timestamped log file)                |

## Examples
    ./mycp a.txt b.txt
    ./mycp -b 64K -p -i -m big.iso backup.iso
    ./mycp -r -m -v -l backup.log mydir/ backup_dir/
    ./mycp -r -j 4 mydir/ backup_dir/
    ./mycp -c -v big.iso backup.iso       # resume a partial copy
    ./mycp -B big.iso /tmp/out.iso        # benchmark buffer sizes

## Notes
- If the destination is an existing directory, a single file is copied into it.
- With -r, the destination directory becomes a copy of the source directory.
- Only regular files and directories are copied (others are skipped and logged).
- Progress bar and file info are disabled when -j is greater than 1.
- Resume (-c) continues after the bytes already in the destination; add -v to
  confirm the final file is identical.

## Files
    src/ (8 .c files)
      main.c       argument parsing, program flow, summary
      copy.c       Levels 1-5 core copy + resume
      display.c    file information display + progress bar
      verify.c     copy verification
      dircopy.c    recursive copy: job queue (linked list) + pthreads workers
      benchmark.c  copy performance benchmark
      logger.c     logging system
      utils.c      read/write loops, size/time/path helpers
    include/ (8 .h files)
      mycp.h       options and statistics types, constants
      copy.h  display.h  verify.h  dircopy.h  benchmark.h  logger.h  utils.h
    tests/       GoogleTest suite + fault-injection layer (see below)
    tools/       valgrind / MISRA helper scripts
    reports/     latest coverage, cppcheck, MISRA and valgrind results
    Makefile

## Testing and quality checks
Requires: gcc, g++, libgtest-dev, gcovr, cppcheck, valgrind (Ubuntu:
`sudo apt install build-essential libgtest-dev gcovr cppcheck valgrind`).

    make test       build and run the 23 GoogleTest tests (166 sub-cases)
    make coverage   tests + gcov/gcovr report (reports/coverage*.txt, coverage.html)
    make cppcheck   static analysis (exit code 1 on any finding)
    make misra      MISRA C:2012 check (cppcheck addon) -> reports/misra_summary.txt
    make valgrind   memcheck (tests + CLI scenarios), helgrind and drd on the -j copy
    make sanitize   unit tests built with AddressSanitizer + UBSan
    make check      everything above

How the tests reach the error paths: the C sources are compiled with
`-include tests/fault_inject.h`, which redirects malloc, strdup, open, read,
write, close, lseek, fstat, stat, lstat, mkdir, opendir, chmod, fchmod,
pthread_create, snprintf, clock_gettime and getpwuid to wrappers in
tests/fault.c. A test can make the Nth call of any of them fail (with a chosen
errno), force short reads/writes, or script the clock. Only the code under test
is affected; the production build does not use any of this.
`main()` is compiled as `mycp_main` in the test build so `main.c` is tested too.

Current results: 23 tests (166 sub-cases, one fixture each) pass; line coverage 509/509 and branch coverage
358/358 (100%) in all 8 source files; cppcheck 0 findings; valgrind clean.
MISRA: see reports/misra_summary.txt (not zero; findings are categorised there).
Note: helgrind reports glibc's internal stdio locking as a race; tools/helgrind.supp
suppresses only stack traces that pass through glibc stdio.

Test layout: each test file defines sub-cases with `CASE(Suite, Group, Name)`;
`GROUP(Suite, Group)` runs a group as one gtest test, and a failure message names
the sub-case (`sub-case: Utils.TimeAndPaths / BaseName`).
