#include "common.hpp"
#include <cerrno>

class Bench : public MycpTest {
protected:
    void SetUp() override
    {
        MycpTest::SetUp();
        put(p("src"), pattern(100000));
    }
    int bench(const std::string &src, const std::string &dst, const options_t &o,
              std::string *out = nullptr, std::string *err = nullptr)
    {
        Capture c;
        int rc = run_benchmark(src.c_str(), dst.c_str(), &o);
        if (out) *out = c.out();
        if (err) *err = c.err();
        return rc;
    }
};

CASE(Bench, Output, PrintsTableForAllBufferSizes)
{
    std::string out;
    EXPECT_EQ(0, bench(p("src"), p("dst"), opts(), &out));
    EXPECT_TRUE(contains(out, "Benchmark: copying"));
    for (const char *label : { "512 B", "1.00 KB", "4.00 KB", "8.00 KB",
                               "16.00 KB", "64.00 KB", "256.00 KB", "1.00 MB" })
        EXPECT_TRUE(contains(out, label)) << label;
    EXPECT_TRUE(contains(out, "Fastest buffer size:"));
}

CASE(Bench, Output, CleansUpTemporaryFile)
{
    EXPECT_EQ(0, bench(p("src"), p("dst"), opts()));
    EXPECT_FALSE(exists(p("dst.bench.tmp")));
    EXPECT_FALSE(exists(p("dst")));
}

CASE(Bench, Output, IgnoresPerCopyOptions)
{
    options_t o = opts();
    o.progress = o.show_info = o.verify = o.resume = 1;
    std::string out;
    EXPECT_EQ(0, bench(p("src"), p("dst"), o, &out));
    EXPECT_FALSE(contains(out, "Verified"));
    EXPECT_FALSE(contains(out, "file info"));
    EXPECT_FALSE(contains(out, "%"));
}

CASE(Bench, Output, DeterministicWinnerAndZeroTimeSpeed)
{
    /* two clock reads per copy: start, end.  durations (s):
       0.50, 0.00, 0.20, 0.10, 0.30, 0.05, 0.40, 0.06 */
    const double v[] = { 0, .50,  1, 1.0,  2, 2.2,  3, 3.1,
                         4, 4.3,  5, 5.05, 6, 6.4,  7, 7.06 };
    fi_clock_script(v, 16);
    std::string out;
    EXPECT_EQ(0, bench(p("src"), p("dst"), opts(), &out));
    EXPECT_TRUE(contains(out, "0.0000       0.00"));       /* zero-time row */
    EXPECT_TRUE(contains(out, "Fastest buffer size: 1.00 KB"));
}

CASE(Bench, Output, FirstSizeCanStayTheWinner)
{
    const double v[] = { 0, .01,  1, 1.5,  2, 2.5,  3, 3.5,
                         4, 4.5,  5, 5.5,  6, 6.5,  7, 7.5 };
    fi_clock_script(v, 16);
    std::string out;
    EXPECT_EQ(0, bench(p("src"), p("dst"), opts(), &out));
    EXPECT_TRUE(contains(out, "Fastest buffer size: 512 B"));
}

CASE(Bench, Errors, MissingSource)
{
    std::string err;
    EXPECT_EQ(-1, bench(p("nope"), p("dst"), opts(), nullptr, &err));
    EXPECT_TRUE(contains(err, "benchmark: bad source or destination path"));
}

CASE(Bench, Errors, DestinationPathTooLong)
{
    std::string longdst(5000, 'x');
    std::string err;
    EXPECT_EQ(-1, bench(p("src"), longdst, opts(), nullptr, &err));
    EXPECT_TRUE(contains(err, "bad source or destination path"));
}

CASE(Bench, Errors, CopyFailureStopsBenchmark)
{
    std::string err;
    EXPECT_EQ(-1, bench(p("src"), p("no/such/dir/dst"), opts(), nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot create"));
}

CASE(Bench, Errors, ResultsAreLogged)
{
    ASSERT_EQ(0, log_open(p("log").c_str()));
    EXPECT_EQ(0, bench(p("src"), p("dst"), opts()));
    log_close();
    EXPECT_TRUE(contains(slurp(p("log")), "benchmark buffer=512"));
}

/* ---- one gtest test per group ---- */
GROUP(Bench, Output)
GROUP(Bench, Errors)
