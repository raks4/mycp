#include "common.hpp"
#include <cerrno>

class Copy : public MycpTest {
protected:
    void SetUp() override
    {
        MycpTest::SetUp();
        data = pattern(10000);
        put(p("src"), data);
    }
    std::string data;
};

/* ---------- plain copies ---------- */
CASE(Copy, Basic, CopiesContentAndFillsStats)
{
    stats_t st = {};
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts(), &st));
    EXPECT_EQ(data, slurp(p("dst")));
    EXPECT_EQ(10000u, st.bytes);
    EXPECT_GE(st.seconds, 0.0);
}

CASE(Copy, Basic, WorksWithVariousBufferSizes)
{
    for (size_t b : { (size_t)1, (size_t)7, (size_t)4096, (size_t)10000,
                      (size_t)65536, (size_t)1048576 }) {
        std::string d = p("d" + std::to_string(b));
        EXPECT_EQ(0, cp(p("src"), d, opts(b))) << "buffer " << b;
        EXPECT_EQ(data, slurp(d)) << "buffer " << b;
    }
}

CASE(Copy, Basic, EmptyFile)
{
    put(p("empty"), "");
    stats_t st = {};
    EXPECT_EQ(0, cp(p("empty"), p("out"), opts(), &st));
    EXPECT_EQ("", slurp(p("out")));
    EXPECT_EQ(0u, st.bytes);
}

CASE(Copy, Basic, StatsPointerMayBeNull)
{
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts(), nullptr));
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, Basic, OverwritesAndTruncatesExistingDestination)
{
    put(p("dst"), std::string(50000, 'Z'));
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts()));
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, Basic, CopiesIntoDevNull)
{
    /* destination on another device: st_dev differs -> not "same file" */
    EXPECT_EQ(0, cp(p("src"), "/dev/null", opts()));
}

CASE(Copy, Basic, ReadRetriesAfterEintr)
{
    fi_fail_at(FI_READ, 1, EINTR);
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts()));
    EXPECT_EQ(data, slurp(p("dst")));
}

/* ---------- source / destination errors ---------- */
CASE(Copy, PathErrors, MissingSource)
{
    std::string err;
    EXPECT_EQ(-1, cp(p("nope"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot open"));
    EXPECT_FALSE(exists(p("dst")));
}

CASE(Copy, PathErrors, FstatFailure)
{
    std::string err;
    fi_fail_at(FI_FSTAT, 1, EIO);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot stat"));
}

CASE(Copy, PathErrors, SourceMustBeRegularFile)
{
    std::string err;
    EXPECT_EQ(-1, cp(dir, p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "not a regular file"));
}

CASE(Copy, PathErrors, RefusesSamePath)
{
    std::string err;
    EXPECT_EQ(-1, cp(p("src"), p("src"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "same file"));
    EXPECT_EQ(data, slurp(p("src")));              /* untouched */
}

CASE(Copy, PathErrors, RefusesHardLinkToSameInode)
{
    ASSERT_EQ(0, link(p("src").c_str(), p("hard").c_str()));
    std::string err;
    EXPECT_EQ(-1, cp(p("src"), p("hard"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "same file"));
    EXPECT_EQ(data, slurp(p("src")));
}

CASE(Copy, PathErrors, DestinationDirectoryMissing)
{
    std::string err;
    EXPECT_EQ(-1, cp(p("src"), p("no/such/dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot create"));
}

CASE(Copy, PathErrors, AllocationFailure)
{
    std::string err;
    fi_fail_at(FI_MALLOC, 1, ENOMEM);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "out of memory"));
}

/* ---------- I/O errors during the copy ---------- */
CASE(Copy, IoErrors, ReadErrorWithoutProgress)
{
    std::string err;
    fi_fail_at(FI_READ, 1, EIO);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "read error"));
}

CASE(Copy, IoErrors, ReadErrorWithProgress)
{
    options_t o = opts(1000);
    o.progress = 1;
    std::string out, err;
    fi_fail_at(FI_READ, 3, EIO);                    /* fails after some progress */
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, &out, &err));
    EXPECT_TRUE(contains(err, "read error"));
    EXPECT_EQ('\n', out.back());                    /* progress_finish ran */
}

CASE(Copy, IoErrors, WriteErrorWithoutProgress)
{
    std::string err;
    fi_fail_at(FI_WRITE, 1, ENOSPC);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "write error"));
}

CASE(Copy, IoErrors, WriteErrorWithProgress)
{
    options_t o = opts(1000);
    o.progress = 1;
    std::string out, err;
    fi_fail_at(FI_WRITE, 2, ENOSPC);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, &out, &err));
    EXPECT_TRUE(contains(err, "write error"));
}

CASE(Copy, IoErrors, CloseErrorIsReported)
{
    std::string err;
    fi_fail_at(FI_CLOSE, 1, EIO);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), opts(), nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "close error"));
}

/* ---------- options ---------- */
CASE(Copy, Options, ProgressBarIsShown)
{
    options_t o = opts(1000);
    o.progress = 1;
    std::string out;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, nullptr, &out));
    EXPECT_TRUE(contains(out, "100%"));
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, Options, ShowInfoPrintsBothSides)
{
    options_t o = opts();
    o.show_info = 1;
    std::string out;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, nullptr, &out));
    EXPECT_TRUE(contains(out, "---- Source file info ----"));
    EXPECT_TRUE(contains(out, "---- Destination file info ----"));
}

CASE(Copy, Options, ShowInfoSurvivesFailingDestinationStat)
{
    options_t o = opts();
    o.show_info = 1;
    std::string out;
    fi_fail_at(FI_STAT, 2, EIO);                    /* stat(dst) after the copy */
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, nullptr, &out));
    EXPECT_TRUE(contains(out, "Source file info"));
    EXPECT_FALSE(contains(out, "Destination file info"));
}

CASE(Copy, Options, PreserveKeepsPermissions)
{
    chmod(p("src").c_str(), 0751);
    options_t o = opts();
    o.preserve = 1;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o));
    EXPECT_EQ((mode_t)0751, mode_of(p("dst")));
}

CASE(Copy, Options, WithoutPreserveUsesDefaultMode)
{
    chmod(p("src").c_str(), 0751);
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts()));
    EXPECT_NE((mode_t)0751, mode_of(p("dst")));
}

CASE(Copy, Options, PreserveFailureIsReported)
{
    options_t o = opts();
    o.preserve = 1;
    std::string err;
    fi_fail_at(FI_FCHMOD, 1, EPERM);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot set permissions"));
}

/* ---------- verification ---------- */
CASE(Copy, Options, VerifySucceeds)
{
    options_t o = opts();
    o.verify = 1;
    std::string out;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, nullptr, &out));
    EXPECT_TRUE(contains(out, "Verified:"));
}

CASE(Copy, Options, VerifyDetectsDifference)
{
    options_t o = opts();
    o.verify = 1;
    std::string err;
    /* /dev/null swallows the data, so the "copy" differs from the source */
    EXPECT_EQ(-1, cp(p("src"), "/dev/null", o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "verification FAILED"));
}

CASE(Copy, Options, VerifyErrorFailsTheCopy)
{
    options_t o = opts();
    o.verify = 1;
    std::string err;
    fi_fail_at(FI_OPEN, 4, EIO);        /* src, dst, then verify's 2nd open */
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "verify: cannot open"));
    EXPECT_FALSE(contains(err, "verification FAILED"));
}

/* ---------- resume ---------- */
CASE(Copy, ResumeAndLog, ResumeContinuesPartialDestination)
{
    put(p("dst"), data.substr(0, 4000));
    options_t o = opts();
    o.resume = 1;
    std::string out;
    stats_t st = {};
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, &st, &out));
    EXPECT_TRUE(contains(out, "Resuming"));
    EXPECT_TRUE(contains(out, "from byte 4000 of 10000"));
    EXPECT_EQ(data, slurp(p("dst")));
    EXPECT_EQ(6000u, st.bytes);                     /* only the missing part */
}

CASE(Copy, ResumeAndLog, ResumeWithProgressStartsAtOffset)
{
    put(p("dst"), data.substr(0, 5000));
    options_t o = opts(1000);
    o.resume = 1;
    o.progress = 1;
    std::string out;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, nullptr, &out));
    EXPECT_TRUE(contains(out, " 60%"));
    EXPECT_FALSE(contains(out, "  0%"));
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, ResumeAndLog, ResumeWithCompleteDestinationCopiesNothing)
{
    put(p("dst"), data);
    options_t o = opts();
    o.resume = 1;
    stats_t st = {};
    EXPECT_EQ(0, cp(p("src"), p("dst"), o, &st));
    EXPECT_EQ(0u, st.bytes);
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, ResumeAndLog, ResumeIgnoresLargerDestination)
{
    put(p("dst"), std::string(20000, 'Q'));
    options_t o = opts();
    o.resume = 1;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o));
    EXPECT_EQ(data, slurp(p("dst")));               /* restarted + truncated */
}

CASE(Copy, ResumeAndLog, ResumeWithoutDestinationStartsFresh)
{
    options_t o = opts();
    o.resume = 1;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o));
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, ResumeAndLog, ResumeOntoDirectoryFails)
{
    std::string err;
    options_t o = opts();
    o.resume = 1;
    EXPECT_EQ(-1, cp(p("src"), dir, o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "cannot create"));
}

CASE(Copy, ResumeAndLog, WithoutResumeFlagPartialFileIsOverwritten)
{
    put(p("dst"), data.substr(0, 4000));
    stats_t st = {};
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts(), &st));
    EXPECT_EQ(10000u, st.bytes);
    EXPECT_EQ(data, slurp(p("dst")));
}

CASE(Copy, ResumeAndLog, ResumeSeekFailureOnSource)
{
    put(p("dst"), data.substr(0, 4000));
    options_t o = opts();
    o.resume = 1;
    std::string err;
    fi_fail_at(FI_LSEEK, 1, EIO);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "lseek failed"));
}

CASE(Copy, ResumeAndLog, ResumeSeekFailureOnDestination)
{
    put(p("dst"), data.substr(0, 4000));
    options_t o = opts();
    o.resume = 1;
    std::string err;
    fi_fail_at(FI_LSEEK, 2, EIO);
    EXPECT_EQ(-1, cp(p("src"), p("dst"), o, nullptr, nullptr, &err));
    EXPECT_TRUE(contains(err, "lseek failed"));
}

/* ---------- logging ---------- */
CASE(Copy, ResumeAndLog, SuccessIsLogged)
{
    ASSERT_EQ(0, log_open(p("log").c_str()));
    EXPECT_EQ(0, cp(p("src"), p("dst"), opts()));
    log_close();
    EXPECT_TRUE(contains(slurp(p("log")), "(10000 bytes)"));
}

CASE(Copy, ResumeAndLog, ResumeIsLogged)
{
    put(p("dst"), data.substr(0, 100));
    ASSERT_EQ(0, log_open(p("log").c_str()));
    options_t o = opts();
    o.resume = 1;
    EXPECT_EQ(0, cp(p("src"), p("dst"), o));
    log_close();
    EXPECT_TRUE(contains(slurp(p("log")), "resuming"));
}

/* ---- one gtest test per group ---- */
GROUP(Copy, Basic)
GROUP(Copy, PathErrors)
GROUP(Copy, IoErrors)
GROUP(Copy, Options)
GROUP(Copy, ResumeAndLog)
